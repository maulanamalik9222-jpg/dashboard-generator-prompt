PREMANKARO CHROME AUTO SS

INSTALASI
1. Ekstrak ZIP extension ke folder permanen. Jangan hapus folder tersebut.
2. Buka chrome://extensions di Google Chrome.
3. Aktifkan Developer mode di kanan atas.
4. Klik Load unpacked.
5. Pilih folder yang berisi manifest.json.
6. Refresh Dashboard PremanKaro dengan Ctrl+F5.
7. Status harus berubah menjadi EXTENSION CHROME AKTIF.

PENGGUNAAN
- Login ke situs tujuan melalui Chrome seperti biasa jika diperlukan.
- Biarkan Dashboard PremanKaro terbuka.
- Klik SS SEKARANG atau SS SEMUA.
- Chrome membuka tab target di belakang, mengambil halaman penuh, lalu menutup tab.

SYARAT OTOMATIS
- Komputer menyala dan tidak sleep.
- Chrome terbuka.
- Extension tetap aktif.
- Dashboard terbuka dan sudah login.

PERINGATAN
Extension meminta izin debugger agar dapat mengambil screenshot halaman penuh.
Pasang hanya pada komputer staf yang dipercaya.
