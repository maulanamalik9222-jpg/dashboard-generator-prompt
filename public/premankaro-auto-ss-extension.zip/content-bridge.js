const DASHBOARD_SOURCE = "PREMANKARO_DASHBOARD";
const EXTENSION_SOURCE = "PREMANKARO_EXTENSION";

window.addEventListener("message", (event) => {
  if (event.source !== window || event.origin !== window.location.origin)
    return;
  const message = event.data;
  if (!message || message.source !== DASHBOARD_SOURCE) return;
  if (message.type !== "PING" && message.type !== "CAPTURE_PAGE") return;

  chrome.runtime.sendMessage(message, (response) => {
    if (chrome.runtime.lastError) {
      window.postMessage(
        {
          source: EXTENSION_SOURCE,
          type: message.type === "PING" ? "PONG" : "CAPTURE_RESULT",
          requestId: message.requestId,
          ok: message.type === "PING",
          error: chrome.runtime.lastError.message,
        },
        window.location.origin,
      );
      return;
    }
    window.postMessage(
      {
        source: EXTENSION_SOURCE,
        ...(response || {}),
        requestId: message.requestId || response?.requestId,
      },
      window.location.origin,
    );
  });
});
