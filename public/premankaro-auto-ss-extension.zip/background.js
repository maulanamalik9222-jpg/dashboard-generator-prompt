const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function waitForTab(tabId, timeoutMs = 45_000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Halaman tidak selesai dimuat dalam 45 detik."));
    }, timeoutMs);
    const listener = (updatedId, info, tab) => {
      if (updatedId !== tabId || info.status !== "complete") return;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(tab);
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) return;
      if (tab.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(tab);
      }
    });
  });
}

async function loadLazyContent(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: async () => {
      const step = Math.max(500, Math.floor(window.innerHeight * 0.8));
      let y = 0;
      let previousTotal = 0;
      let stableRounds = 0;
      while (stableRounds < 3 && y < 60_000) {
        const total = Math.max(
          document.documentElement.scrollHeight,
          document.body?.scrollHeight || 0,
        );
        window.scrollTo(0, y);
        await new Promise((resolve) => setTimeout(resolve, 160));
        y += step;
        if (y >= total) {
          if (total === previousTotal) stableRounds += 1;
          else stableRounds = 0;
          previousTotal = total;
          y = Math.max(0, total - window.innerHeight);
        }
      }
      window.scrollTo(0, 0);
      await new Promise((resolve) => setTimeout(resolve, 350));
    },
  });
}

async function inspectPage(tabId) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const text = (document.body?.innerText || "")
        .slice(0, 20_000)
        .toLowerCase();
      const challengePhrases = [
        "verify you are human",
        "performing security verification",
        "checking your browser",
        "security verification",
        "turnstile",
      ];
      const viewportWidth = document.documentElement.clientWidth || innerWidth;
      const documentHeight = Math.max(
        document.documentElement.scrollHeight,
        document.body?.scrollHeight || 0,
      );
      const widths = new Map();
      for (const element of document.querySelectorAll("body *")) {
        const rect = element.getBoundingClientRect();
        if (
          rect.width < 480 ||
          rect.width >= viewportWidth * 0.96 ||
          rect.height < documentHeight * 0.3 ||
          rect.left < -4 ||
          rect.right > viewportWidth + 4
        )
          continue;
        const roundedWidth = Math.round(rect.width / 8) * 8;
        widths.set(roundedWidth, (widths.get(roundedWidth) || 0) + 1);
      }
      const dominantContentWidth = [...widths.entries()]
        .filter(([width]) => width >= viewportWidth * 0.48)
        .sort((a, b) => b[1] - a[1] || b[0] - a[0])[0]?.[0];
      const bodyWidth = Math.round(
        document.body?.getBoundingClientRect().width || 0,
      );
      const captureWidth =
        dominantContentWidth ||
        (bodyWidth >= 480 && bodyWidth < viewportWidth * 0.96
          ? bodyWidth
          : viewportWidth);
      return {
        title: document.title,
        finalUrl: location.href,
        challenge: challengePhrases.some((phrase) => text.includes(phrase)),
        captureWidth: Math.min(viewportWidth, captureWidth),
      };
    },
  });
  return result?.result || { title: "", finalUrl: "", challenge: false };
}

async function expandScrollableContainers(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      document.documentElement.style.setProperty(
        "overflow",
        "visible",
        "important",
      );
      document.body?.style.setProperty("overflow", "visible", "important");
      for (const element of document.querySelectorAll("body *")) {
        const style = getComputedStyle(element);
        const scrollable =
          /(auto|scroll)/.test(style.overflowY) &&
          element.scrollHeight > element.clientHeight + 120 &&
          element.clientWidth > 280;
        if (!scrollable) continue;
        element.style.setProperty("max-height", "none", "important");
        element.style.setProperty(
          "height",
          `${element.scrollHeight}px`,
          "important",
        );
        element.style.setProperty("overflow-y", "visible", "important");
      }
      window.scrollTo(0, 0);
    },
  });
  await wait(500);
}

function debuggerCommand(tabId, method, params = {}) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params, (result) => {
      if (chrome.runtime.lastError)
        reject(new Error(chrome.runtime.lastError.message));
      else resolve(result);
    });
  });
}

function attachDebugger(tabId) {
  return new Promise((resolve, reject) => {
    chrome.debugger.attach({ tabId }, "1.3", () => {
      if (chrome.runtime.lastError)
        reject(new Error(chrome.runtime.lastError.message));
      else resolve();
    });
  });
}

function detachDebugger(tabId) {
  return new Promise((resolve) => chrome.debugger.detach({ tabId }, resolve));
}

function detectUsefulWidth(bitmap) {
  const sampleWidth = Math.min(640, bitmap.width);
  const sampleHeight = Math.min(900, bitmap.height);
  const scaleX = sampleWidth / bitmap.width;
  const scaleY = sampleHeight / bitmap.height;
  const canvas = new OffscreenCanvas(sampleWidth, sampleHeight);
  const context = canvas.getContext("2d", { alpha: false });
  context.drawImage(bitmap, 0, 0, sampleWidth, sampleHeight);
  const pixels = context.getImageData(0, 0, sampleWidth, sampleHeight).data;

  // Warna tepi kanan biasanya merupakan background kosong situs.
  const edgeSamples = [];
  for (
    let y = 0;
    y < sampleHeight;
    y += Math.max(1, Math.floor(sampleHeight / 80))
  ) {
    const offset = (y * sampleWidth + sampleWidth - 2) * 4;
    edgeSamples.push([pixels[offset], pixels[offset + 1], pixels[offset + 2]]);
  }
  const median = (values) =>
    values.sort((a, b) => a - b)[Math.floor(values.length / 2)];
  const background = [0, 1, 2].map((channel) =>
    median(edgeSamples.map((value) => value[channel])),
  );

  let lastActiveColumn = sampleWidth - 1;
  const rowStep = Math.max(1, Math.floor(sampleHeight / 360));
  const requiredActivePixels = Math.max(
    4,
    Math.floor((sampleHeight / rowStep) * 0.012),
  );
  for (let x = sampleWidth - 1; x >= Math.floor(sampleWidth * 0.42); x -= 1) {
    let activePixels = 0;
    for (let y = 0; y < sampleHeight; y += rowStep) {
      const offset = (y * sampleWidth + x) * 4;
      const distance =
        Math.abs(pixels[offset] - background[0]) +
        Math.abs(pixels[offset + 1] - background[1]) +
        Math.abs(pixels[offset + 2] - background[2]);
      if (distance > 72) activePixels += 1;
      if (activePixels >= requiredActivePixels) break;
    }
    if (activePixels >= requiredActivePixels) {
      lastActiveColumn = x;
      break;
    }
  }

  const detected = Math.ceil((lastActiveColumn + 10) / scaleX);
  const emptyRatio = (bitmap.width - detected) / bitmap.width;
  return emptyRatio >= 0.08
    ? Math.max(480, Math.min(bitmap.width, detected))
    : bitmap.width;
}

async function compressJpeg(base64) {
  let blob = await (await fetch(`data:image/jpeg;base64,${base64}`)).blob();
  const bitmap = await createImageBitmap(blob);
  // Mode screenshot dashboard menggunakan satu viewport desktop yang sudah pas.
  // Jangan memotong berdasarkan warna karena background situs dapat berulang.
  const usefulWidth = bitmap.width;
  let scale = Math.min(1, 1050 / usefulWidth, 14_000 / bitmap.height);
  let quality = 0.62;
  for (let attempt = 0; attempt < 7; attempt += 1) {
    const width = Math.max(480, Math.round(usefulWidth * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = new OffscreenCanvas(width, height);
    const context = canvas.getContext("2d", { alpha: false });
    context.drawImage(
      bitmap,
      0,
      0,
      usefulWidth,
      bitmap.height,
      0,
      0,
      width,
      height,
    );
    blob = await canvas.convertToBlob({ type: "image/jpeg", quality });
    if (blob.size <= 720_000) {
      const bytes = new Uint8Array(await blob.arrayBuffer());
      let binary = "";
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) {
        binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
      }
      return `data:image/jpeg;base64,${btoa(binary)}`;
    }
    scale *= 0.78;
    quality = Math.max(0.32, quality - 0.07);
  }
  throw new Error(
    "Screenshot terlalu panjang untuk disimpan. Pendekkan halaman target.",
  );
}

async function capturePage(payload) {
  let tabId;
  let debuggerAttached = false;
  try {
    const tab = await chrome.tabs.create({
      url: payload.category.url,
      active: false,
    });
    tabId = tab.id;
    await waitForTab(tabId);
    await attachDebugger(tabId);
    debuggerAttached = true;
    await debuggerCommand(tabId, "Page.enable");
    await debuggerCommand(tabId, "Emulation.setDeviceMetricsOverride", {
      width: 1920,
      height: 960,
      deviceScaleFactor: 1,
      mobile: false,
      screenWidth: 1920,
      screenHeight: 960,
    });
    await wait(1_200);
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => window.scrollTo(0, 0),
    });
    await wait(500);
    const pageInfo = await inspectPage(tabId);
    const metrics = await debuggerCommand(tabId, "Page.getLayoutMetrics");
    const viewport = metrics.cssLayoutViewport || metrics.layoutViewport;
    if (!viewport?.clientWidth || !viewport?.clientHeight)
      throw new Error("Ukuran layar situs tidak dapat dibaca.");
    const screenshot = await debuggerCommand(tabId, "Page.captureScreenshot", {
      format: "jpeg",
      quality: 78,
      fromSurface: true,
      captureBeyondViewport: false,
      optimizeForSpeed: true,
      clip: {
        x: viewport.pageX || 0,
        y: viewport.pageY || 0,
        width: viewport.clientWidth,
        height: viewport.clientHeight,
        scale: 1,
      },
    });
    const dataUrl = await compressJpeg(screenshot.data);
    return { ...pageInfo, dataUrl };
  } finally {
    if (debuggerAttached && tabId)
      await detachDebugger(tabId).catch(() => undefined);
    if (tabId) await chrome.tabs.remove(tabId).catch(() => undefined);
  }
}

async function capturePageWithRetry(payload) {
  let lastError;
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      return await capturePage(payload);
    } catch (error) {
      lastError = error;
      if (attempt < 2) await wait(1_500);
    }
  }
  throw lastError || new Error("Screenshot gagal setelah dua percobaan.");
}

// Chrome debugger lebih stabil jika hanya satu tab diproses pada satu waktu.
let captureQueue = Promise.resolve();

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.source !== "PREMANKARO_DASHBOARD") return false;
  if (message.type === "PING") {
    sendResponse({ type: "PONG", ok: true });
    return false;
  }
  if (message.type !== "CAPTURE_PAGE") return false;
  const queuedCapture = captureQueue.then(() => capturePageWithRetry(message));
  captureQueue = queuedCapture.catch(() => undefined);
  queuedCapture
    .then((result) =>
      sendResponse({
        type: "CAPTURE_RESULT",
        requestId: message.requestId,
        ok: true,
        result,
      }),
    )
    .catch((error) =>
      sendResponse({
        type: "CAPTURE_RESULT",
        requestId: message.requestId,
        ok: false,
        error: error instanceof Error ? error.message : "Screenshot gagal.",
      }),
    );
  return true;
});
