const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function waitForTab(tabId, timeoutMs = 45_000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Halaman tidak selesai dimuat dalam 45 detik."));
    }, timeoutMs);
    const listener = (updatedId, info, tab) => {
      if (updatedId !== tabId || info.status !== "complete") return;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(tab);
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) return;
      if (tab.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(tab);
      }
    });
  });
}

async function loadLazyContent(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: async () => {
      const total = Math.max(
        document.documentElement.scrollHeight,
        document.body?.scrollHeight || 0,
      );
      const step = Math.max(500, Math.floor(window.innerHeight * 0.8));
      for (let y = 0; y < total; y += step) {
        window.scrollTo(0, y);
        await new Promise((resolve) => setTimeout(resolve, 120));
      }
      window.scrollTo(0, 0);
      await new Promise((resolve) => setTimeout(resolve, 350));
    },
  });
}

async function inspectPage(tabId) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const text = (document.body?.innerText || "")
        .slice(0, 20_000)
        .toLowerCase();
      const challengePhrases = [
        "verify you are human",
        "performing security verification",
        "checking your browser",
        "security verification",
        "turnstile",
      ];
      return {
        title: document.title,
        finalUrl: location.href,
        challenge: challengePhrases.some((phrase) => text.includes(phrase)),
      };
    },
  });
  return result?.result || { title: "", finalUrl: "", challenge: false };
}

function debuggerCommand(tabId, method, params = {}) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params, (result) => {
      if (chrome.runtime.lastError)
        reject(new Error(chrome.runtime.lastError.message));
      else resolve(result);
    });
  });
}

function attachDebugger(tabId) {
  return new Promise((resolve, reject) => {
    chrome.debugger.attach({ tabId }, "1.3", () => {
      if (chrome.runtime.lastError)
        reject(new Error(chrome.runtime.lastError.message));
      else resolve();
    });
  });
}

function detachDebugger(tabId) {
  return new Promise((resolve) => chrome.debugger.detach({ tabId }, resolve));
}

async function compressJpeg(base64) {
  let blob = await (await fetch(`data:image/jpeg;base64,${base64}`)).blob();
  if (blob.size <= 1_700_000) return `data:image/jpeg;base64,${base64}`;

  const bitmap = await createImageBitmap(blob);
  let scale = Math.min(1, 1200 / bitmap.width);
  let quality = 0.68;
  for (let attempt = 0; attempt < 7; attempt += 1) {
    const width = Math.max(640, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = new OffscreenCanvas(width, height);
    const context = canvas.getContext("2d", { alpha: false });
    context.drawImage(bitmap, 0, 0, width, height);
    blob = await canvas.convertToBlob({ type: "image/jpeg", quality });
    if (blob.size <= 1_700_000) {
      const bytes = new Uint8Array(await blob.arrayBuffer());
      let binary = "";
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) {
        binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
      }
      return `data:image/jpeg;base64,${btoa(binary)}`;
    }
    scale *= 0.82;
    quality = Math.max(0.38, quality - 0.07);
  }
  throw new Error(
    "Screenshot terlalu panjang untuk disimpan. Pendekkan halaman target.",
  );
}

async function capturePage(payload) {
  let tabId;
  let debuggerAttached = false;
  try {
    const tab = await chrome.tabs.create({
      url: payload.category.url,
      active: false,
    });
    tabId = tab.id;
    await waitForTab(tabId);
    await wait(2_000);
    await loadLazyContent(tabId).catch(() => undefined);
    const pageInfo = await inspectPage(tabId);

    await attachDebugger(tabId);
    debuggerAttached = true;
    await debuggerCommand(tabId, "Page.enable");
    const screenshot = await debuggerCommand(tabId, "Page.captureScreenshot", {
      format: "jpeg",
      quality: 72,
      fromSurface: true,
      captureBeyondViewport: true,
      optimizeForSpeed: true,
    });
    const dataUrl = await compressJpeg(screenshot.data);
    return { ...pageInfo, dataUrl };
  } finally {
    if (debuggerAttached && tabId)
      await detachDebugger(tabId).catch(() => undefined);
    if (tabId) await chrome.tabs.remove(tabId).catch(() => undefined);
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.source !== "PREMANKARO_DASHBOARD") return false;
  if (message.type === "PING") {
    sendResponse({ type: "PONG", ok: true });
    return false;
  }
  if (message.type !== "CAPTURE_PAGE") return false;
  capturePage(message)
    .then((result) =>
      sendResponse({
        type: "CAPTURE_RESULT",
        requestId: message.requestId,
        ok: true,
        result,
      }),
    )
    .catch((error) =>
      sendResponse({
        type: "CAPTURE_RESULT",
        requestId: message.requestId,
        ok: false,
        error: error instanceof Error ? error.message : "Screenshot gagal.",
      }),
    );
  return true;
});
